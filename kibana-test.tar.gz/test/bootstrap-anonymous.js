
function kbnBundlesLoader() {
  var modules = {};

  function has(prop) {
    return Object.prototype.hasOwnProperty.call(modules, prop);
  }

  function define(key, bundleRequire, bundleModuleKey) {
    if (has(key)) {
      throw new Error('__kbnBundles__ already has a module defined for "' + key + '"');
    }

    modules[key] = {
      bundleRequire,
      bundleModuleKey,
    };
  }

  function get(key) {
    if (!has(key)) {
      throw new Error('__kbnBundles__ does not have a module defined for "' + key + '"');
    }

    return modules[key].bundleRequire(modules[key].bundleModuleKey);
  }

  return { has: has, define: define, get: get };
}

var kbnCsp = JSON.parse(document.querySelector('kbn-csp').getAttribute('data'));
window.__kbnStrictCsp__ = kbnCsp.strictCsp;
window.__kbnThemeTag__ = "v8light";
window.__kbnPublicPath__ = {"core":"/test/46909/bundles/core/","kbn-ui-shared-deps-src":"/test/46909/bundles/kbn-ui-shared-deps-src/","kbn-ui-shared-deps-npm":"/test/46909/bundles/kbn-ui-shared-deps-npm/","security":"/test/46909/bundles/plugin/security/8.0.0/","esUiShared":"/test/46909/bundles/plugin/esUiShared/kibana/","data":"/test/46909/bundles/plugin/data/kibana/","inspector":"/test/46909/bundles/plugin/inspector/kibana/","kibanaReact":"/test/46909/bundles/plugin/kibanaReact/kibana/","kibanaUtils":"/test/46909/bundles/plugin/kibanaUtils/kibana/","spaces":"/test/46909/bundles/plugin/spaces/8.0.0/","home":"/test/46909/bundles/plugin/home/kibana/","features":"/test/46909/bundles/plugin/features/8.0.0/","licensing":"/test/46909/bundles/plugin/licensing/0.0.1/"};
window.__kbnBundles__ = kbnBundlesLoader();

if (window.__kbnStrictCsp__ && window.__kbnCspNotEnforced__) {
  var legacyBrowserError = document.getElementById('kbn_legacy_browser_error');
  legacyBrowserError.style.display = 'flex';
} else {
  if (!window.__kbnCspNotEnforced__ && window.console) {
    window.console.log("^ A single error about an inline script not firing due to content security policy is expected!");
  }
  var loadingMessage = document.getElementById('kbn_loading_message');
  loadingMessage.style.display = 'flex';

  window.onload = function () {
    function failure() {
      // make subsequent calls to failure() noop
      failure = function () {};

      var err = document.createElement('h1');
      err.style['color'] = 'white';
      err.style['font-family'] = 'monospace';
      err.style['text-align'] = 'center';
      err.style['background'] = '#F44336';
      err.style['padding'] = '25px';
      err.innerText = document.querySelector('[data-error-message]').dataset.errorMessage;

      document.body.innerHTML = err.outerHTML;
    }

    var stylesheetTarget = document.querySelector('head meta[name="add-styles-here"]')
    function loadStyleSheet(url, cb) {
      var dom = document.createElement('link');
      dom.rel = 'stylesheet';
      dom.type = 'text/css';
      dom.href = url;
      dom.addEventListener('error', failure);
      dom.addEventListener('load', cb);
      document.head.insertBefore(dom, stylesheetTarget);
    }

    var scriptsTarget = document.querySelector('head meta[name="add-scripts-here"]')
    function loadScript(url, cb) {
      var dom = document.createElement('script');
      dom.async = false;
      dom.src = url;
      dom.addEventListener('error', failure);
      dom.addEventListener('load', cb);
      document.head.insertBefore(dom, scriptsTarget);
    }

    function load(urls, cb) {
      var pending = urls.length;
      urls.forEach(function (url) {
        var innerCb = function () {
          pending = pending - 1;
          if (pending === 0 && typeof cb === 'function') {
            cb();
          }
        }

        if (typeof url !== 'string') {
          load(url, innerCb);
        } else if (url.slice(-4) === '.css') {
          loadStyleSheet(url, innerCb);
        } else {
          loadScript(url, innerCb);
        }
      });
    }

    load([
      '/test/46909/bundles/kbn-ui-shared-deps-npm/kbn-ui-shared-deps-npm.dll.js','/test/46909/bundles/kbn-ui-shared-deps-src/kbn-ui-shared-deps-src.js','/test/46909/bundles/core/core.entry.js','/test/46909/bundles/plugin/security/8.0.0/security.plugin.js','/test/46909/bundles/plugin/esUiShared/kibana/esUiShared.plugin.js','/test/46909/bundles/plugin/data/kibana/data.plugin.js','/test/46909/bundles/plugin/inspector/kibana/inspector.plugin.js','/test/46909/bundles/plugin/kibanaReact/kibana/kibanaReact.plugin.js','/test/46909/bundles/plugin/kibanaUtils/kibana/kibanaUtils.plugin.js','/test/46909/bundles/plugin/spaces/8.0.0/spaces.plugin.js','/test/46909/bundles/plugin/home/kibana/home.plugin.js','/test/46909/bundles/plugin/features/8.0.0/features.plugin.js','/test/46909/bundles/plugin/licensing/0.0.1/licensing.plugin.js'
    ], function () {
      __kbnBundles__.get('entry/core/public').__kbnBootstrap__();
    });
  }
}
  